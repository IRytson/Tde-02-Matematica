import pygame
import sys

# Inicialização do Pygame
pygame.init()

# Configurações da janela
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Reflexão de Objeto")

# Cores
white = (255, 255, 255)

# Carregar a imagem do objeto
obj_image = pygame.image.load('pikachu.png')
obj_rect = obj_image.get_rect()

# Eixo de reflexão (horizontal ou vertical)
reflexion_axis = "horizontal"  # "horizontal" ou "vertical"

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Limpar a tela
    screen.fill(white)

    # Realizar a reflexão horizontal
    if reflexion_axis == "horizontal":
        reflected_image = pygame.transform.flip(obj_image, False, True)
    # Realizar a reflexão vertical
    elif reflexion_axis == "vertical":
        reflected_image = pygame.transform.flip(obj_image, True, False)
    else:
        raise ValueError("Eixo de reflexão inválido")

    reflected_rect = reflected_image.get_rect()
    reflected_rect.center = obj_rect.center

    # Desenhar o objeto refletido
    screen.blit(reflected_image, reflected_rect.topleft)

    # Atualizar a tela
    pygame.display.flip()

    # Manter a imagem refletida até que o programa seja fechado
    pygame.time.delay(10)

# Encerrar o Pygame
pygame.quit()
sys.exit()
