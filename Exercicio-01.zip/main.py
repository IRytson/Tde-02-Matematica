import pygame
import sys

# Inicialização do Pygame
pygame.init()

# Configurações da janela
largura, altura = 800, 600
janela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Translação de Bolinha")

# Cores
branco = (255, 255, 255)
vermelho = (255, 0, 0)

# Posição inicial da bolinha
bola_x, bola_y = largura // 2, altura // 2

# Velocidade da translação
velocidade = 0.5

while True:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Captura de teclas pressionadas
    teclas = pygame.key.get_pressed()

    # Movimenta a bolinha na direção especificada pelas teclas pressionadas
    if teclas[pygame.K_LEFT]:
        bola_x -= velocidade
    if teclas[pygame.K_RIGHT]:
        bola_x += velocidade
    if teclas[pygame.K_UP]:
        bola_y -= velocidade
    if teclas[pygame.K_DOWN]:
        bola_y += velocidade

    # Preenche a tela com a cor branca
    janela.fill(branco)

    # Desenha a bolinha na nova posição
    pygame.draw.circle(janela, vermelho, (bola_x, bola_y), 25)  # O último argumento é o raio da bolinha

    # Atualiza a tela
    pygame.display.flip()

# Encerra o Pygame
pygame.quit()
