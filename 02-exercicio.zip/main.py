import pygame
import sys
import math

# Inicialização do Pygame
pygame.init()

# Configurações da janela
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Rotação de Objeto")

# Cores
white = (255, 255, 255)

# Definir o ponto de rotação
rotation_point = (400, 300)

# Carregar a imagem do objeto
obj_image = pygame.image.load('goku.png')
obj_rect = obj_image.get_rect()

# Ângulo inicial
angle = 0

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Limpar a tela
    screen.fill(white)

    # Calcular a nova posição do objeto após a rotação
    rotated_image = pygame.transform.rotate(obj_image, angle)
    rotated_rect = rotated_image.get_rect(center=rotation_point)

    # Desenhar o objeto rotacionado
    screen.blit(rotated_image, rotated_rect.topleft)

    # Atualizar a tela
    pygame.display.flip()

    # Aumentar o ângulo para uma rotação contínua
    angle += 1

    # Limitar a taxa de quadros (FPS)
    pygame.time.delay(10)

# Encerrar o Pygame
pygame.quit()
sys.exit()
