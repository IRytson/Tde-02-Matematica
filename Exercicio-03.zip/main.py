import pygame
import sys

# Inicialização do Pygame
pygame.init()

# Configurações da janela
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Escala de Objeto")

# Cores
white = (255, 255, 255)

# Definir o ponto de escala
scale_point = (200, 100)

# Carregar a imagem do objeto
obj_image = pygame.image.load('naruto.jpg')  
obj_rect = obj_image.get_rect()

# Fator de escala inicial
scale_factor = 0.5

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Limpar a tela
    screen.fill(white)

    # Calcular a nova posição e tamanho do objeto após a escala
    scaled_width = int(obj_rect.width * scale_factor)
    scaled_height = int(obj_rect.height * scale_factor)
    scaled_image = pygame.transform.scale(obj_image, (scaled_width, scaled_height))
    scaled_rect = scaled_image.get_rect()

    # Define o ponto de escala como o centro da imagem
    scaled_rect.center = scale_point

    # Desenhar o objeto escalado
    screen.blit(scaled_image, scaled_rect.topleft)

    # Atualizar a tela
    pygame.display.flip()

    # Alterar o fator de escala (por exemplo, aumentar em 0.01 a cada quadro)
    scale_factor += 0.0001

    # Limitar a taxa de quadros (FPS)
    pygame.time.delay(10)

# Encerrar o Pygame
pygame.quit()
sys.exit()
